import { pageKind, mergeVideos, linksFromText, composeMarkdown, exportFilename } from './core.js';
import { collectYouTube, readNotebook } from './page-actions.js';

const $ = id => document.getElementById(id);
const state = { videos: [], sources: [], notebook: null, notebookTabId: null, tab: null, view: 'videos', job: null };
const available = Boolean(globalThis.chrome?.runtime?.id);
let saveQueue = Promise.resolve();

function notify(message, error = false) {
  $('notice').textContent = message;
  $('notice').className = 'notice' + (error ? ' error' : '');
  $('notice').hidden = false;
}
function persistVideos() {
  const videos = state.videos.map(v => ({ ...v }));
  saveQueue = saveQueue.catch(() => {}).then(() => chrome.storage.local.set({ videos }));
  saveQueue.catch(() => notify('목록을 브라우저에 저장하지 못했습니다. 패널을 닫기 전에 링크를 복사해 주세요.', true));
}
function setView(view) {
  if (view !== state.view) $('notice').hidden = true;
  state.view = view;
  $('videos-view').hidden = view !== 'videos';
  $('sources-view').hidden = view !== 'sources';
  for (const key of ['videos', 'sources']) {
    $(`tab-${key}`).classList.toggle('active', view === key);
    $(`tab-${key}`).setAttribute('aria-pressed', String(view === key));
  }
}
async function refreshContext() {
  if (!available) return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  state.tab = tab;
  const kind = pageKind(tab?.url);
  const labels = { youtube: '유튜브에서 영상을 모을 수 있어요', notebook: '이 노트북에서 자료를 꺼낼 수 있어요', 'notebook-home': '자료가 있는 노트북을 열어 주세요', other: '유튜브 또는 노트북 탭을 열어 주세요' };
  $('context-label').textContent = labels[kind];
  $('context-dot').classList.toggle('ready', ['youtube', 'notebook'].includes(kind));
  updateButtons();
}
async function runInTab(tabId, func, args, world = 'ISOLATED') {
  if (!Number.isInteger(tabId)) throw new Error('사용할 탭을 먼저 열어 주세요.');
  let results;
  try { results = await chrome.scripting.executeScript({ target: { tabId }, func, args: [args], world }); }
  catch { throw new Error('페이지에 연결할 수 없습니다. 해당 탭을 새로고침하고 다시 시도해 주세요.'); }
  const value = results?.[0]?.result;
  if (!value) throw new Error('페이지에서 응답이 없습니다. 새로고침하고 다시 시도해 주세요.');
  if (value.error) throw new Error(value.error);
  return value;
}
function updateButtons() {
  const busy = Boolean(state.job);
  const chosen = state.videos.filter(v => v.selected).length;
  const selected = state.sources.filter(s => s.selected);
  const ready = selected.some(s => s.status === 'done');
  $('collect-videos').disabled = busy || !available || pageKind(state.tab?.url) !== 'youtube';
  $('load-sources').disabled = busy || !available || pageKind(state.tab?.url) !== 'notebook';
  $('extract-sources').disabled = busy || !selected.length;
  $('extract-sources').textContent = selected.some(s => s.status === 'error') ? '실패·미완료 자료 다시 추출' : '선택한 자료 추출하기';
  for (const id of ['copy-links', 'save-links', 'send-notebook']) $(id).disabled = busy || !chosen;
  for (const id of ['download-markdown', 'copy-markdown']) $(id).disabled = busy || !ready;
  for (const id of ['clear-videos', 'select-videos']) $(id).disabled = busy || !state.videos.length;
  $('select-sources').disabled = busy || !state.sources.length;
  $('add-urls').disabled = busy || !available;
  $('open-youtube').disabled = !available;
  $('open-notebook').disabled = !available;
  $('video-limit').disabled = busy;
  for (const input of document.querySelectorAll('.item input')) input.disabled = busy;
}
function setAllState(input, items) {
  const n = items.filter(i => i.selected).length;
  input.checked = Boolean(items.length) && n === items.length;
  input.indeterminate = n > 0 && n < items.length;
}
function makeItem(item, type) {
  const row = document.createElement('div');
  row.className = 'item' + (item.selected ? ' selected' : '');
  const checkbox = document.createElement('input');
  checkbox.type = 'checkbox'; checkbox.checked = item.selected;
  checkbox.setAttribute('aria-label', item.title + ' 선택');
  checkbox.addEventListener('change', () => { item.selected = checkbox.checked; if (type === 'video') { persistVideos(); renderVideos(); } else renderSources(); });
  const body = document.createElement('div'); body.className = 'item-body';
  const title = document.createElement(item.url && /^https?:\/\//.test(item.url) ? 'a' : 'span');
  title.className = 'item-title'; title.textContent = item.title;
  if (title.tagName === 'A') { title.href = item.url; title.target = '_blank'; title.rel = 'noreferrer noopener'; }
  body.append(title);
  const meta = document.createElement('div'); meta.className = 'item-meta';
  const badge = document.createElement('span'); badge.className = 'kind'; badge.textContent = type === 'video' ? 'YouTube' : item.kind;
  const subtitle = document.createElement('span'); subtitle.textContent = item.channel || (type === 'video' ? '영상 링크' : item.status === 'done' ? `${item.text.length.toLocaleString()}자` : '본문 자료');
  meta.append(badge, subtitle); body.append(meta);
  if (item.error) { const error = document.createElement('div'); error.className = 'item-error'; error.textContent = item.error; body.append(error); }
  row.append(checkbox, body);
  if (type === 'source') { const status = document.createElement('span'); status.className = 'status ' + item.status; status.textContent = { idle: '대기', loading: '추출 중', done: '완료', error: '확인 필요' }[item.status]; row.append(status); }
  return row;
}
function renderVideos() {
  $('video-list').replaceChildren(...state.videos.map(v => makeItem(v, 'video')));
  $('video-count').textContent = state.videos.length;
  $('video-selected').textContent = state.videos.filter(v => v.selected).length;
  $('video-empty').hidden = Boolean(state.videos.length);
  $('video-actions').hidden = !state.videos.length;
  setAllState($('select-videos'), state.videos); updateButtons();
}
function renderSources() {
  $('source-list').replaceChildren(...state.sources.map(s => makeItem(s, 'source')));
  $('source-count').textContent = state.sources.length;
  $('source-selected').textContent = state.sources.filter(s => s.selected).length + '개 선택';
  $('source-empty').hidden = Boolean(state.sources.length);
  $('source-actions').hidden = !state.sources.length;
  $('notebook-info').hidden = !state.notebook;
  $('notebook-title').textContent = state.notebook?.title || '';
  setAllState($('select-sources'), state.sources); updateButtons();
}
function startJob(label, total) {
  const job = { cancelled: false };
  state.job = job; $('activity').hidden = false; $('stop-job').disabled = false;
  $('activity-text').textContent = label;
  if (total) { $('progress').max = total; $('progress').value = 0; } else $('progress').removeAttribute('value');
  $('notice').hidden = true; updateButtons();
  return job;
}
function finishJob() { state.job = null; $('activity').hidden = true; updateButtons(); }
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));

async function collectVideos() {
  await refreshContext();
  if (pageKind(state.tab?.url) !== 'youtube') throw new Error('유튜브 검색 결과, 채널 또는 재생목록 탭을 열어 주세요.');
  const tabId = state.tab.id;
  const limit = Number($('video-limit').value);
  const previous = state.videos.length;
  const job = startJob('영상 목록을 읽고 있어요');
  let collected = [], unchanged = 0;
  try {
    for (let round = 0; round < 45 && !job.cancelled; round++) {
      const result = await runInTab(tabId, collectYouTube, { scroll: false });
      const count = collected.length;
      collected = mergeVideos(collected, result.videos, limit || 500);
      state.videos = mergeVideos(state.videos, collected);
      renderVideos();
      $('activity-text').textContent = `${result.label}에서 ${collected.length}개 찾았어요`;
      if (!limit || collected.length >= limit || result.single) break;
      unchanged = collected.length === count ? unchanged + 1 : 0;
      if (unchanged >= 6) break;
      await runInTab(tabId, collectYouTube, { scroll: true });
      await pause(800);
    }
    const added = state.videos.length - previous;
    if (state.videos.length >= 500) notify('목록은 최대 500개까지 보관합니다. 필요한 링크를 저장한 뒤 목록을 비워 주세요.');
    else if (job.cancelled) notify(`수집을 멈췄습니다. 지금까지 추가한 ${added}개는 목록에 남아 있어요.`);
    else if (!collected.length) notify('일반 영상을 찾지 못했습니다. 목록이 보이는지 확인하고, 조금 스크롤한 뒤 다시 시도해 주세요.', true);
    else notify(added ? `${added}개를 추가했어요. 필요한 영상만 선택해 노트북으로 가져가세요.` : '이미 모은 영상입니다. 다른 검색 결과나 채널에서도 이어서 모을 수 있어요.');
  } finally { persistVideos(); finishJob(); }
}
function selectedLinks() { return state.videos.filter(v => v.selected).map(v => v.url).join('\n'); }
async function copy(text) {
  if (!text) throw new Error('먼저 자료를 선택해 주세요.');
  try { await navigator.clipboard.writeText(text); }
  catch { throw new Error('클립보드 복사가 막혔습니다. 파일 저장 버튼을 이용해 주세요.'); }
}
function download(text, filename, type = 'text/markdown;charset=utf-8') {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const anchor = document.createElement('a'); anchor.href = url; anchor.download = filename;
  document.body.append(anchor); anchor.click(); anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}
async function openNotebook() {
  const tabs = await chrome.tabs.query({ currentWindow: true });
  const existing = tabs.find(t => pageKind(t.url) === 'notebook') || tabs.find(t => pageKind(t.url) === 'notebook-home');
  if (existing) await chrome.tabs.update(existing.id, { active: true });
  else await chrome.tabs.create({ url: 'https://notebook.google.com/' });
}
async function loadSources() {
  await refreshContext();
  if (pageKind(state.tab?.url) !== 'notebook') throw new Error('자료가 들어 있는 개별 노트북을 먼저 열어 주세요.');
  const tabId = state.tab.id;
  const job = startJob('소스 목록을 읽고 있어요');
  try {
    const result = await runInTab(tabId, readNotebook, { operation: 'list' }, 'MAIN');
    if (job.cancelled) return;
    const old = state.notebook?.url === result.notebook.url ? new Map(state.sources.map(s => [s.id, s])) : new Map();
    state.notebook = result.notebook; state.notebookTabId = tabId;
    state.sources = result.sources.map(s => ({ ...s, selected: old.get(s.id)?.selected ?? true, text: old.get(s.id)?.text || '', status: old.get(s.id)?.status === 'done' ? 'done' : 'idle', error: '' }));
    $('handoff-note').hidden = true;
    renderSources();
    notify(state.sources.length ? `${state.sources.length}개 소스를 불러왔어요. 저장할 자료를 선택하고 추출하세요.` : '이 노트북에는 소스가 없습니다. 먼저 자료를 추가해 주세요.');
  } finally { finishJob(); }
}
async function extractSources() {
  if (!state.notebook) throw new Error('소스 목록을 먼저 불러와 주세요.');
  const pending = state.sources.filter(s => s.selected && s.status !== 'done');
  if (!pending.length) { notify('선택한 자료는 모두 추출됐어요. .md 파일로 저장하세요.'); return; }
  const job = startJob(`0 / ${pending.length}개 추출`, pending.length);
  const notebookId = state.notebook.id, tabId = state.notebookTabId;
  let cursor = 0, finished = 0;
  const worker = async () => {
    while (cursor < pending.length && !job.cancelled) {
      const source = pending[cursor++]; source.status = 'loading'; source.error = ''; renderSources();
      try {
        const result = await runInTab(tabId, readNotebook, { operation: 'text', notebookId, sourceId: source.id }, 'MAIN');
        source.text = result.text; source.status = 'done';
      } catch (error) { source.status = 'error'; source.error = error.message; }
      finished++; $('activity-text').textContent = `${finished} / ${pending.length}개 추출`; $('progress').value = finished;
      renderSources();
    }
  };
  try {
    await Promise.all(Array.from({ length: Math.min(3, pending.length) }, worker));
    const selected = state.sources.filter(s => s.selected);
    const done = selected.filter(s => s.status === 'done').length;
    notify(`${job.cancelled ? '중지했습니다. ' : ''}${selected.length}개 중 ${done}개를 추출했어요.${done ? ' .md 파일로 저장할 수 있습니다.' : ''}${done < selected.length ? '\n미완료 자료는 다시 추출할 수 있고, 저장 파일에도 누락 목록을 남깁니다.' : ''}`, done === 0);
  } finally { finishJob(); }
}
function on(id, action) {
  $(id).addEventListener('click', () => Promise.resolve().then(action).catch(error => notify(error.message || '작업을 완료하지 못했습니다.', true)));
}

on('tab-videos', () => setView('videos')); on('tab-sources', () => setView('sources'));
on('refresh-context', refreshContext); on('collect-videos', collectVideos); on('load-sources', loadSources); on('extract-sources', extractSources);
on('stop-job', () => { if (state.job) { state.job.cancelled = true; $('stop-job').disabled = true; $('activity-text').textContent = '진행 중인 요청이 끝나면 멈춥니다…'; } });
on('open-youtube', () => chrome.tabs.create({ url: 'https://www.youtube.com/' }));
on('open-notebook', openNotebook);
on('add-urls', () => {
  const videos = linksFromText($('manual-urls').value);
  if (!videos.length) throw new Error('일반 유튜브 영상 주소를 붙여 넣어 주세요. 쇼츠·채널 주소는 목록으로 추가할 수 없습니다.');
  const before = state.videos.length;
  state.videos = mergeVideos(state.videos, videos); persistVideos(); renderVideos(); $('manual-urls').value = '';
  notify(`${state.videos.length - before}개의 링크를 추가했어요.`);
});
on('clear-videos', () => { state.videos = []; persistVideos(); renderVideos(); notify('모은 영상 목록을 비웠습니다.'); });
on('copy-links', async () => { await copy(selectedLinks()); notify(`${state.videos.filter(v => v.selected).length}개의 링크를 복사했어요.`); });
on('save-links', () => { download(selectedLinks() + '\n', '유튜브_영상_링크.txt', 'text/plain;charset=utf-8'); notify('링크 목록 다운로드를 시작했어요.'); });
on('send-notebook', async () => { await copy(selectedLinks()); $('handoff-note').hidden = false; setView('sources'); await openNotebook(); await refreshContext(); notify('링크가 클립보드에 있어요. 노트북의 ‘소스 추가 → 웹사이트’에 붙여 넣으세요.'); });
on('download-markdown', () => { download(composeMarkdown(state.notebook, state.sources), exportFilename(state.notebook.title)); notify('다운로드를 시작했어요. 저장한 .md 파일을 AI 채팅에 첨부하거나 Obsidian으로 옮기세요.'); });
on('copy-markdown', async () => { await copy(composeMarkdown(state.notebook, state.sources)); notify('추출한 본문을 복사했어요.'); });
$('select-videos').addEventListener('change', event => { state.videos.forEach(v => { v.selected = event.target.checked; }); persistVideos(); renderVideos(); });
$('select-sources').addEventListener('change', event => { state.sources.forEach(s => { s.selected = event.target.checked; }); renderSources(); });

async function init() {
  if (!available) {
    $('context-label').textContent = '브라우저 확장 프로그램으로 설치해 주세요';
    notify('이 화면은 확장 프로그램 안에서 동작합니다. 오른쪽 위 ? 버튼에서 설치 방법을 확인하세요.');
    renderVideos(); renderSources(); return;
  }
  const stored = await chrome.storage.local.get('videos');
  state.videos = mergeVideos([], Array.isArray(stored.videos) ? stored.videos : []);
  renderVideos(); renderSources(); await refreshContext();
  if (pageKind(state.tab?.url) === 'notebook') setView('sources');
  chrome.tabs.onActivated.addListener(() => refreshContext().catch(() => {}));
  chrome.tabs.onUpdated.addListener((tabId, change) => { if (tabId === state.tab?.id && (change.url || change.status === 'complete')) refreshContext().catch(() => {}); });
}
init().catch(error => notify(error.message, true));
